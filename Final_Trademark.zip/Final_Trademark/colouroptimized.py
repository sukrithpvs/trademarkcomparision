# Fix for PyTorch-Streamlit compatibility issue
import os
import torch
# Multiple fixes for the torch.classes path issue
torch.classes.__path__ = []

import streamlit as st
import cv2
import numpy as np
import jellyfish
from PIL import Image
from sklearn.cluster import KMeans
import easyocr
import matplotlib.pyplot as plt
from scipy.spatial.distance import cosine
import torchvision
from torchvision import transforms
from torchvision.models import ViT_B_16_Weights
import io
import tempfile
import glob
import pandas as pd
import warnings
import concurrent.futures
from functools import partial
import time
from colormath.color_objects import sRGBColor, LabColor
from colormath.color_conversions import convert_color
from colormath.color_diff import delta_e_cie2000

# Suppress sklearn convergence warnings
warnings.filterwarnings("ignore", category=UserWarning, module="sklearn")

class LogoSimilarityRanker:
    def __init__(self):
        """Initialize the Logo Similarity Ranker with strict color comparison"""
        # Set device for CUDA acceleration
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        
        # GPU optimizations
        if torch.cuda.is_available():
            torch.backends.cudnn.benchmark = True
            torch.backends.cudnn.deterministic = False
            torch.backends.cuda.matmul.allow_tf32 = True
            torch.backends.cudnn.allow_tf32 = True
            os.environ['PYTORCH_CUDA_ALLOC_CONF'] = 'max_split_size_mb:256'
            torch.cuda.empty_cache()
            print("CUDA optimizations enabled")
        
        # Initialize OCR engine with GPU support
        with st.spinner('Loading GPU-accelerated OCR engine...'):
            self.reader = easyocr.Reader(['en'], gpu=torch.cuda.is_available())
            
        # Initialize Vision Transformer (ViT) model
        with st.spinner('Loading GPU-accelerated Vision Transformer model...'):
            self.vit_model = torchvision.models.vit_b_16(weights=ViT_B_16_Weights.DEFAULT)
            self.vit_model.heads = torch.nn.Identity()
            self.vit_model.eval()
            self.vit_model = self.vit_model.to(self.device)
            
            if self.device.type == 'cuda':
                self.vit_model = self.vit_model.half()
            
            self.transform = transforms.Compose([
                transforms.Resize((224, 224)),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
            ])
            
            # Warm up GPU
            if torch.cuda.is_available():
                dummy_input = torch.randn(8, 3, 224, 224).to(self.device).half()
                with torch.no_grad():
                    _ = self.vit_model(dummy_input)
                torch.cuda.empty_cache()
                print("GPU warmup completed")
            
        self.infringement_threshold = 70.0
        self._compile_cuda_kernels()
    
    def _compile_cuda_kernels(self):
        """Pre-compile CUDA kernels for faster color processing"""
        if not torch.cuda.is_available():
            return
            
        try:
            dummy_colors1 = torch.randn(6, 3, device=self.device)
            dummy_colors2 = torch.randn(6, 3, device=self.device)
            _ = torch.cdist(dummy_colors1, dummy_colors2)
            
            dummy_matrix = torch.randn(1000, 3, device=self.device)
            _ = torch.norm(dummy_matrix, dim=1)
            
            torch.cuda.empty_cache()
            print("CUDA kernels pre-compiled successfully")
        except Exception as e:
            print(f"CUDA kernel compilation warning: {e}")
    
    def extract_text_batch_optimized(self, image_paths, max_workers=12):
        """Optimized batch text extraction"""
        def extract_single_text(path):
            try:
                results = self.reader.readtext(path)
                return ' '.join([result[1] for result in results]).strip().lower()
            except:
                return ""
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            texts = list(executor.map(extract_single_text, image_paths))
        
        return texts
    
    def extract_text(self, image_path):
        """Extract text from logo image using GPU-accelerated EasyOCR"""
        try:
            results = self.reader.readtext(image_path)
            text = ' '.join([result[1] for result in results])
            return text.strip().lower()
        except Exception as e:
            return ""
    
    def calculate_text_similarity(self, text1, text2):
        """Calculate text similarity using Levenshtein distance"""
        if not text1 or not text2:
            return 0.0
            
        distance = jellyfish.levenshtein_distance(text1, text2)
        max_len = max(len(text1), len(text2))
        
        if max_len == 0:
            return 0.0
            
        similarity = (1 - (distance / max_len)) * 100
        return similarity
    
    def extract_dominant_colors_strict(self, image_path, n_colors=8):
        """Strict color extraction with better filtering and preprocessing"""
        try:
            image = cv2.imread(image_path)
            if image is None:
                return np.zeros((n_colors, 3)), np.ones(n_colors) / n_colors
            
            # Convert to RGB
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            
            # Resize to larger size for better color representation
            image = cv2.resize(image, (200, 200))
            
            # Apply bilateral filter to reduce noise while preserving edges
            image = cv2.bilateralFilter(image, 9, 75, 75)
            
            # Reshape for clustering
            pixels = image.reshape(-1, 3)
            
            # More aggressive filtering to remove background and noise
            # Remove very dark pixels (likely background)
            pixel_sums = pixels.sum(axis=1)
            brightness_mask = (pixel_sums > 50) & (pixel_sums < 700)
            
            if brightness_mask.sum() > n_colors * 15:
                pixels = pixels[brightness_mask]
            
            # Convert to HSV for better saturation filtering
            hsv_pixels = cv2.cvtColor(pixels.reshape(-1, 1, 3).astype(np.uint8), cv2.COLOR_RGB2HSV)
            saturation = hsv_pixels[:, 0, 1]
            value = hsv_pixels[:, 0, 2]
            
            # Keep only pixels with reasonable saturation and value
            color_mask = (saturation > 40) & (value > 50)
            
            if color_mask.sum() > n_colors * 8:
                pixels = pixels[color_mask]
            
            # Remove grayscale-like colors
            rgb_std = np.std(pixels, axis=1)
            color_variation_mask = rgb_std > 15  # Colors with some variation between RGB channels
            
            if color_variation_mask.sum() > n_colors * 5:
                pixels = pixels[color_variation_mask]
            
            # Perform clustering with more iterations for better results
            if len(pixels) > n_colors:
                kmeans = KMeans(
                    n_clusters=n_colors,
                    random_state=42,
                    n_init=15,
                    max_iter=300,
                    tol=1e-4
                )
                kmeans.fit(pixels)
                colors = kmeans.cluster_centers_
                
                labels = kmeans.labels_
                weights = np.bincount(labels, minlength=n_colors) / len(labels)
                
                # Sort by weight (most prominent colors first)
                sorted_indices = np.argsort(weights)[::-1]
                colors = colors[sorted_indices]
                weights = weights[sorted_indices]
                
                # Filter out colors with very low weights
                significant_mask = weights > 0.03  # At least 3% presence
                if significant_mask.sum() >= 3:  # Keep at least 3 colors
                    colors = colors[significant_mask]
                    weights = weights[significant_mask]
                    # Renormalize weights
                    weights = weights / weights.sum()
                    
                    # Pad if necessary
                    if len(colors) < n_colors:
                        pad_size = n_colors - len(colors)
                        colors = np.vstack([colors, np.zeros((pad_size, 3))])
                        weights = np.concatenate([weights, np.zeros(pad_size)])
            else:
                colors = np.zeros((n_colors, 3))
                if len(pixels) > 0:
                    colors[:len(pixels)] = pixels[:n_colors]
                weights = np.ones(n_colors) / n_colors
            
            return colors.astype(np.uint8), weights
            
        except Exception as e:
            print(f"Strict color extraction failed: {e}")
            return np.zeros((n_colors, 3)), np.ones(n_colors) / n_colors

    def extract_dominant_colors_batch_strict(self, image_paths, n_colors=8):
        """Strict batch color extraction"""
        def extract_colors_single(path):
            return self.extract_dominant_colors_strict(path, n_colors)
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
            results = list(executor.map(extract_colors_single, image_paths))
        
        all_colors = [result[0] for result in results]
        all_weights = [result[1] for result in results]
        
        return all_colors, all_weights

    def calculate_color_similarity_strict(self, colors1, weights1, colors2, weights2):
        """Strict color similarity calculation with proper Delta E thresholds"""
        try:
            if torch.cuda.is_available():
                # GPU-accelerated calculation
                colors1_gpu = torch.tensor(colors1, dtype=torch.float32, device=self.device)
                colors2_gpu = torch.tensor(colors2, dtype=torch.float32, device=self.device)
                weights1_gpu = torch.tensor(weights1, dtype=torch.float32, device=self.device)
                
                # Convert to LAB space on GPU
                lab_colors1 = self.rgb_to_lab_gpu_batch(colors1_gpu)
                lab_colors2 = self.rgb_to_lab_gpu_batch(colors2_gpu)
                
                # Calculate pairwise distances
                distances = torch.cdist(lab_colors1.unsqueeze(0), lab_colors2.unsqueeze(0)).squeeze(0)
                
                # Find minimum distances for each significant color
                min_distances, _ = torch.min(distances, dim=1)
                
                # Only consider colors with significant presence
                significant_mask = weights1_gpu >= 0.05
                
                if torch.sum(significant_mask) > 0:
                    weighted_distances = min_distances[significant_mask] * weights1_gpu[significant_mask]
                    total_weight = torch.sum(weights1_gpu[significant_mask])
                    avg_distance = torch.sum(weighted_distances) / total_weight
                else:
                    avg_distance = torch.tensor(100.0, device=self.device)
                
                avg_distance_cpu = avg_distance.cpu().item()
            else:
                # CPU fallback
                avg_distance_cpu = self.calculate_color_similarity_cpu_strict(colors1, weights1, colors2, weights2)
            
            # Much stricter Delta E to similarity conversion
            if avg_distance_cpu <= 1:
                similarity = 95 - (avg_distance_cpu * 5)  # 95% to 90%
            elif avg_distance_cpu <= 3:
                similarity = 90 - ((avg_distance_cpu - 1) * 20)  # 90% to 50%
            elif avg_distance_cpu <= 6:
                similarity = 50 - ((avg_distance_cpu - 3) * 10)  # 50% to 20%
            elif avg_distance_cpu <= 10:
                similarity = 20 - ((avg_distance_cpu - 6) * 4)  # 20% to 4%
            else:
                similarity = max(0, 4 - ((avg_distance_cpu - 10) * 0.5))  # 4% to 0%
            
            # Additional penalty for completely different color families
            penalty = self.calculate_color_family_penalty(colors1, weights1, colors2, weights2)
            similarity = similarity * (1 - penalty)
            
            return max(0, min(100, similarity))
            
        except Exception as e:
            print(f"Strict color similarity calculation failed: {e}")
            return 0.0
    
    def calculate_color_family_penalty(self, colors1, weights1, colors2, weights2):
        """Calculate penalty for completely different color families"""
        try:
            # Define color families in HSV space
            def get_color_family(rgb_color):
                hsv = cv2.cvtColor(np.uint8([[rgb_color]]), cv2.COLOR_RGB2HSV)[0][0]
                hue = hsv[0]
                sat = hsv[1]
                val = hsv[2]
                
                # Low saturation = grayscale family
                if sat < 50:
                    return 'grayscale'
                
                # Color families based on hue
                if hue < 15 or hue > 165:
                    return 'red'
                elif hue < 35:
                    return 'orange'
                elif hue < 75:
                    return 'yellow'
                elif hue < 105:
                    return 'green'
                elif hue < 135:
                    return 'cyan'
                else:
                    return 'blue'
            
            # Get dominant color families for each image
            families1 = {}
            families2 = {}
            
            for color, weight in zip(colors1, weights1):
                if weight > 0.05:  # Only significant colors
                    family = get_color_family(color)
                    families1[family] = families1.get(family, 0) + weight
            
            for color, weight in zip(colors2, weights2):
                if weight > 0.05:  # Only significant colors
                    family = get_color_family(color)
                    families2[family] = families2.get(family, 0) + weight
            
            # Calculate overlap between color families
            all_families = set(families1.keys()) | set(families2.keys())
            overlap = 0
            
            for family in all_families:
                weight1 = families1.get(family, 0)
                weight2 = families2.get(family, 0)
                overlap += min(weight1, weight2)
            
            # Penalty is inverse of overlap
            penalty = max(0, 1 - overlap * 2)  # Strong penalty for no overlap
            
            return penalty
            
        except Exception as e:
            print(f"Color family penalty calculation failed: {e}")
            return 0.0
    
    def calculate_color_similarity_cpu_strict(self, colors1, weights1, colors2, weights2):
        """Strict CPU color similarity calculation"""
        try:
            total_distance = 0
            total_weight = 0
            
            # Convert to LAB space
            lab_colors1 = []
            lab_colors2 = []
            
            for color in colors1:
                lab_colors1.append(self.rgb_to_lab_accurate(color))
            
            for color in colors2:
                lab_colors2.append(self.rgb_to_lab_accurate(color))
            
            lab_colors1 = np.array(lab_colors1)
            lab_colors2 = np.array(lab_colors2)
            
            # Calculate distances for significant colors only
            for i, (lab1, weight1) in enumerate(zip(lab_colors1, weights1)):
                if weight1 < 0.05:  # Skip insignificant colors
                    continue
                
                min_delta_e = float('inf')
                
                for lab2 in lab_colors2:
                    try:
                        color1_lab = LabColor(lab1[0], lab1[1], lab1[2])
                        color2_lab = LabColor(lab2[0], lab2[1], lab2[2])
                        delta_e = delta_e_cie2000(color1_lab, color2_lab)
                        min_delta_e = min(min_delta_e, delta_e)
                    except:
                        euclidean_dist = np.linalg.norm(lab1 - lab2)
                        min_delta_e = min(min_delta_e, euclidean_dist)
                
                total_distance += min_delta_e * weight1
                total_weight += weight1
            
            if total_weight > 0:
                return total_distance / total_weight
            else:
                return 100.0
                
        except Exception as e:
            print(f"CPU strict color similarity failed: {e}")
            return 100.0

    def rgb_to_lab_gpu_batch(self, rgb_colors):
        """Batch RGB to LAB conversion on GPU using PyTorch"""
        try:
            # Normalize RGB to 0-1 range
            rgb_normalized = rgb_colors / 255.0
            
            # Gamma correction
            mask = rgb_normalized > 0.04045
            rgb_linear = torch.where(
                mask,
                torch.pow((rgb_normalized + 0.055) / 1.055, 2.4),
                rgb_normalized / 12.92
            )
            
            # RGB to XYZ transformation matrix
            transform_matrix = torch.tensor([
                [0.4124564, 0.3575761, 0.1804375],
                [0.2126729, 0.7151522, 0.0721750],
                [0.0193339, 0.1191920, 0.9503041]
            ], device=self.device, dtype=torch.float32)
            
            xyz = torch.matmul(rgb_linear, transform_matrix.T)
            
            # Normalize by D65 illuminant
            d65 = torch.tensor([95.047, 100.000, 108.883], device=self.device, dtype=torch.float32)
            xyz = xyz / d65
            
            # XYZ to LAB
            mask = xyz > 0.008856
            f_xyz = torch.where(
                mask,
                torch.pow(xyz, 1/3),
                (7.787 * xyz) + (16/116)
            )
            
            L = (116 * f_xyz[:, 1]) - 16
            a = 500 * (f_xyz[:, 0] - f_xyz[:, 1])
            b = 200 * (f_xyz[:, 1] - f_xyz[:, 2])
            
            return torch.stack([L, a, b], dim=1)
            
        except Exception as e:
            print(f"GPU LAB conversion failed: {e}")
            # Fallback to CPU
            lab_colors = []
            for color in rgb_colors.cpu().numpy():
                lab_colors.append(self.rgb_to_lab_accurate(color))
            return torch.tensor(lab_colors, device=self.device)

    def rgb_to_lab_accurate(self, rgb_color):
        """Convert RGB to LAB using colormath library for accuracy"""
        try:
            rgb_normalized = rgb_color / 255.0
            rgb_color_obj = sRGBColor(
                rgb_normalized[0], 
                rgb_normalized[1], 
                rgb_normalized[2]
            )
            lab_color = convert_color(rgb_color_obj, LabColor)
            return np.array([lab_color.lab_l, lab_color.lab_a, lab_color.lab_b])
        except Exception as e:
            return self.rgb_to_lab_manual(rgb_color)
    
    def rgb_to_lab_manual(self, rgb_color):
        """Manual RGB to LAB conversion as fallback"""
        try:
            rgb_normalized = rgb_color / 255.0
            
            def gamma_correct(c):
                return np.where(c > 0.04045, np.power((c + 0.055) / 1.055, 2.4), c / 12.92)
            
            rgb_linear = gamma_correct(rgb_normalized)
            
            xyz = np.dot(rgb_linear, [
                [0.4124564, 0.3575761, 0.1804375],
                [0.2126729, 0.7151522, 0.0721750],
                [0.0193339, 0.1191920, 0.9503041]
            ])
            
            xyz = xyz / [95.047, 100.000, 108.883]
            
            def f(t):
                return np.where(t > 0.008856, np.power(t, 1/3), (7.787 * t) + (16/116))
            
            fx, fy, fz = f(xyz[0]), f(xyz[1]), f(xyz[2])
            
            L = (116 * fy) - 16
            a = 500 * (fx - fy)
            b = 200 * (fy - fz)
            
            return np.array([L, a, b])
        except:
            return np.array([50, 0, 0])
    
    def extract_vit_features_batch_optimized(self, image_paths, batch_size=1024):
        """Highly optimized batch ViT feature extraction"""
        all_features = []
        
        for i in range(0, len(image_paths), batch_size):
            batch_paths = image_paths[i:i + batch_size]
            batch_tensors = []
            
            def load_and_transform(path):
                try:
                    image = Image.open(path).convert('RGB')
                    return self.transform(image)
                except Exception:
                    return torch.zeros(3, 224, 224)
            
            with concurrent.futures.ThreadPoolExecutor(max_workers=16) as executor:
                batch_tensors = list(executor.map(load_and_transform, batch_paths))
            
            if batch_tensors:
                batch_tensor = torch.stack(batch_tensors).to(self.device, non_blocking=True)
                
                if self.device.type == 'cuda':
                    batch_tensor = batch_tensor.half()
                
                with torch.no_grad():
                    if self.device.type == 'cuda':
                        with torch.amp.autocast("cuda"):
                            features = self.vit_model(batch_tensor)
                    else:
                        features = self.vit_model(batch_tensor)
                
                all_features.extend(features.cpu().float().numpy())
                
                if i % (batch_size * 4) == 0:
                    torch.cuda.empty_cache()
        
        return all_features
    
    def extract_vit_features(self, image_path):
        """Extract deep features from the logo using CUDA-accelerated Vision Transformer"""
        try:
            image = Image.open(image_path).convert('RGB')
            image_tensor = self.transform(image).unsqueeze(0).to(self.device, non_blocking=True)
            
            if self.device.type == 'cuda':
                image_tensor = image_tensor.half()
            
            with torch.no_grad():
                if self.device.type == 'cuda':
                    with torch.amp.autocast("cuda"):
                        features = self.vit_model(image_tensor)
                else:
                    features = self.vit_model(image_tensor)
            
            return features.cpu().float().numpy().flatten()
        except Exception:
            return np.zeros(768)
    
    def calculate_aggregated_scores(self, text_score, image_score):
        """Calculate final aggregated score based on the specified rules"""
        if image_score >= 75 and text_score >= 75:
            final_score = 0.5 * image_score + 0.5 * text_score
        elif image_score < 25 and text_score < 25:
            final_score = 0.5 * image_score + 0.5 * text_score
        elif image_score >= 75 and text_score < 30:
            final_score = 0.7 * image_score + 0.3 * text_score
        elif text_score >= 75 and image_score < 30:
            final_score = 0.3 * image_score + 0.7 * text_score
        else:
            final_score = 0.5 * image_score + 0.5 * text_score
        
        return final_score
    
    def process_logos_batch_strict(self, reference_logo_path, comparison_paths, batch_size=1024):
        """Strict batch processing with accurate color comparison"""
        
        # Extract reference features once
        ref_vit_features = self.extract_vit_features(reference_logo_path)
        ref_colors, ref_weights = self.extract_dominant_colors_strict(reference_logo_path)
        ref_text = self.extract_text(reference_logo_path)
        
        all_results = []
        
        for i in range(0, len(comparison_paths), batch_size):
            batch_paths = comparison_paths[i:i + batch_size]
            
            # Strict batch processing
            batch_vit_features = self.extract_vit_features_batch_optimized(batch_paths, batch_size)
            batch_colors, batch_weights = self.extract_dominant_colors_batch_strict(batch_paths)
            batch_texts = self.extract_text_batch_optimized(batch_paths)
            
            # Calculate similarities for batch
            for j, path in enumerate(batch_paths):
                try:
                    # Text similarity
                    text_score = self.calculate_text_similarity(ref_text, batch_texts[j])
                    
                    # Strict color similarity
                    color_score = self.calculate_color_similarity_strict(
                        ref_colors, ref_weights, batch_colors[j], batch_weights[j]
                    )
                    
                    # ViT similarity
                    vit_sim = 1 - cosine(ref_vit_features, batch_vit_features[j])
                    vit_score = vit_sim * 100
                    
                    # Calculate image score (60% ViT + 40% Color for better color influence)
                    image_score = 0.6 * vit_score + 0.4 * color_score
                    
                    # Calculate final aggregated score
                    final_score = self.calculate_aggregated_scores(text_score, image_score)
                    
                    result = {
                        'logo_path': path,
                        'logo_name': os.path.basename(path),
                        'text_similarity': text_score,
                        'color_similarity': color_score,
                        'vit_similarity': vit_score,
                        'image_score': image_score,
                        'final_similarity': final_score,
                        'infringement_detected': final_score >= self.infringement_threshold,
                        'text1': ref_text,
                        'text2': batch_texts[j]
                    }
                    
                    all_results.append(result)
                    
                except Exception as e:
                    print(f"Error processing {path}: {e}")
                    continue
            
            if i % (batch_size * 2) == 0 and torch.cuda.is_available():
                torch.cuda.empty_cache()
        
        return all_results
    
    def calculate_similarity(self, reference_logo_path, comparison_logo_path):
        """Calculate overall similarity between two logos with strict color comparison"""
        results = {}
        
        try:
            # Text extraction
            text1 = self.extract_text(reference_logo_path)
            text2 = self.extract_text(comparison_logo_path)
            
            text_score = self.calculate_text_similarity(text1, text2)
            results['text_similarity'] = text_score
            results['text1'] = text1
            results['text2'] = text2
            
            # Strict color similarity
            colors1, weights1 = self.extract_dominant_colors_strict(reference_logo_path)
            colors2, weights2 = self.extract_dominant_colors_strict(comparison_logo_path)
            
            color_score = self.calculate_color_similarity_strict(colors1, weights1, colors2, weights2)
            
            # ViT features
            features1 = self.extract_vit_features(reference_logo_path)
            features2 = self.extract_vit_features(comparison_logo_path)
            
            # Calculate ViT similarity
            vit_sim = 1 - cosine(features1, features2)
            vit_score = vit_sim * 100
            
            # Calculate image score (60% ViT + 40% Color)
            image_score = 0.6 * vit_score + 0.4 * color_score
            
            # Calculate final aggregated score
            final_score = self.calculate_aggregated_scores(text_score, image_score)
            
            results['color_similarity'] = color_score
            results['vit_similarity'] = vit_score
            results['image_score'] = image_score
            results['final_similarity'] = final_score
            results['infringement_detected'] = final_score >= self.infringement_threshold
            
            return results
            
        except Exception as e:
            print(f"Similarity calculation error: {e}")
            return {
                'text_similarity': 0.0,
                'text1': '',
                'text2': '',
                'color_similarity': 0.0,
                'vit_similarity': 0.0,
                'image_score': 0.0,
                'final_similarity': 0.0,
                'infringement_detected': False
            }

def save_uploaded_file(uploaded_file):
    """Save an uploaded file to a temporary location and return the path"""
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix='.png') as temp_file:
            temp_file.write(uploaded_file.getvalue())
            return temp_file.name
    except Exception as e:
        st.error(f"Failed to save uploaded file: {str(e)}")
        return None

def get_image_files_from_folder(folder_path):
    """Get all image files from a folder"""
    image_extensions = ['*.jpg', '*.jpeg', '*.png', '*.gif', '*.bmp']
    
    image_files = []
    for extension in image_extensions:
        image_files.extend(glob.glob(os.path.join(folder_path, extension)))
    
    return image_files

def main():
    st.set_page_config(
        page_title="Strict Color Similarity Ranker",
        page_icon="🎯",
        layout="wide"
    )
    
    st.title("🎯 Strict Color Similarity Logo Ranking System")
    
    # Display GPU status
    if torch.cuda.is_available():
        gpu_name = torch.cuda.get_device_name()
        gpu_memory = torch.cuda.get_device_properties(0).total_memory / 1e9
        st.success(f"🚀 CUDA acceleration enabled! Using GPU: {gpu_name}")
        st.info(f"💾 GPU Memory: {gpu_memory:.1f} GB")
    else:
        st.warning("⚠️ CUDA not available. Running on CPU.")
    
    st.markdown("""
    This **strict color comparison** system provides accurate results through:
    - **🎯 Strict Delta E thresholds** for realistic color similarity
    - **🔍 Advanced color filtering** to focus on meaningful colors
    - **🏷️ Color family analysis** with penalties for different color schemes
    - **⚡ GPU-accelerated processing** for fast computation
    - **🎨 Better color extraction** with noise reduction and saturation filtering
    """)
    
    # Initialize ranker with error handling
    if 'ranker' not in st.session_state:
        try:
            with st.spinner('🚀 Initializing strict color analysis system...'):
                st.session_state.ranker = LogoSimilarityRanker()
        except Exception as e:
            st.error(f"Failed to initialize ranker: {str(e)}")
            st.stop()
    
    # Sidebar for settings
    with st.sidebar:
        st.header("⚙️ Strict Analysis Settings")
        
        batch_size = st.selectbox(
            "Batch Size",
            [512, 1024, 2048],
            index=1,
            help="Larger batch sizes utilize GPU better"
        )
        
        max_images = st.selectbox(
            "Max Images to Process",
            [1000, 2000, 5000, 10000],
            index=1,
            help="Maximum number of images to process"
        )
        
        # GPU monitoring
        if torch.cuda.is_available() and st.button("🔍 Check GPU Status"):
            memory_allocated = torch.cuda.memory_allocated() / 1e9
            memory_reserved = torch.cuda.memory_reserved() / 1e9
            
            st.metric("GPU Memory Allocated", f"{memory_allocated:.2f} GB")
            st.metric("GPU Memory Reserved", f"{memory_reserved:.2f} GB")
        
        if torch.cuda.is_available() and st.button("🧹 Clear GPU Cache"):
            torch.cuda.empty_cache()
            st.success("GPU cache cleared!")
        
        # Infringement threshold
        infringement_threshold = st.slider(
            "Infringement Threshold (%)", 
            min_value=30.0, 
            max_value=90.0, 
            value=70.0, 
            step=1.0
        )
        st.session_state.ranker.infringement_threshold = infringement_threshold
        
        st.header("🎯 Strict Analysis Info")
        st.info("""
        **Strict Color Analysis:**
        - Delta E ≤ 1: 90-95% similarity
        - Delta E ≤ 3: 50-90% similarity  
        - Delta E ≤ 6: 20-50% similarity
        - Delta E > 10: <4% similarity
        
        **Additional Features:**
        - Color family penalties
        - Saturation filtering
        - Background noise removal
        - Grayscale detection
        """)
    
    # Reference logo uploader
    st.header("📁 Reference Logo")
    reference_logo = st.file_uploader("Upload your reference logo", type=["jpg", "jpeg", "png"])
    
    # Folder path input for comparison logos
    st.header("📂 Comparison Logos Folder")
    folder_path = st.text_input("Enter the folder path containing logos to compare", "")
    
    # Process logos if reference logo is uploaded and folder path is provided
    if reference_logo and folder_path:
        if not os.path.exists(folder_path):
            st.error(f"Folder path '{folder_path}' does not exist. Please provide a valid folder path.")
        else:
            image_files = get_image_files_from_folder(folder_path)
            
            if not image_files:
                st.warning(f"No image files found in '{folder_path}'. Please ensure the folder contains image files.")
            else:
                st.success(f"Found {len(image_files)} image files in the folder.")
                
                # Display a sample of images found (up to 5)
                st.subheader("Sample Images Found")
                cols = st.columns(min(5, len(image_files)))
                for i, col in enumerate(cols):
                    if i < len(image_files):
                        try:
                            img = Image.open(image_files[i])
                            col.image(img, caption=os.path.basename(image_files[i]), width=100)
                        except Exception:
                            col.error(f"Failed to load {os.path.basename(image_files[i])}")
                
                # Add a button to start analysis
                if st.button("🎯 Start Strict Color Analysis"):
                    try:
                        start_time = time.time()
                        
                        with st.spinner("🎯 Analyzing logos with strict color comparison..."):
                            # Save reference logo
                            reference_logo_path = save_uploaded_file(reference_logo)
                            
                            if reference_logo_path is None:
                                st.error("Failed to save reference logo")
                                st.stop()
                            
                            # Display the reference logo
                            st.subheader("Reference Logo")
                            st.image(reference_logo, width=200)
                            
                            # Process logos using strict batch processing
                            images_to_process = min(max_images, len(image_files))
                            
                            similarity_results = st.session_state.ranker.process_logos_batch_strict(
                                reference_logo_path, 
                                image_files[:images_to_process], 
                                batch_size=batch_size
                            )
                            
                            processing_time = time.time() - start_time
                            
                            if not similarity_results:
                                st.error("No images were successfully processed")
                                st.stop()
                            
                            # Sort results by final similarity (highest to lowest)
                            similarity_results.sort(key=lambda x: x['final_similarity'], reverse=True)
                            
                            # Display performance metrics
                            images_per_second = len(similarity_results) / processing_time
                            st.success(f"✅ Processed {len(similarity_results)} images in {processing_time:.2f} seconds")
                            st.info(f"🎯 **Strict analysis speed: {images_per_second:.1f} images/second**")
                            
                            # Display ranked results
                            st.subheader("🏆 Strict Color Analysis Results")
                            
                            # Count potential infringements
                            infringement_count = sum(1 for result in similarity_results if result['infringement_detected'])
                            
                            if infringement_count > 0:
                                st.warning(f"⚠️ Potential trademark infringement detected in {infringement_count} logo(s)!")
                            
                            # Display top results
                            for i, result in enumerate(similarity_results[:20]):
                                with st.container():
                                    col1, col2 = st.columns([1, 3])
                                    
                                    with col1:
                                        try:
                                            img = Image.open(result['logo_path'])
                                            st.image(img, caption=f"Logo {i+1}", width=150)
                                        except Exception:
                                            st.error(f"Failed to display image")
                                    
                                    with col2:
                                        if result['infringement_detected']:
                                            st.markdown(f"**Rank {i+1}** - Final Score: **{result['final_similarity']:.2f}%** - "
                                                      f"⚠️ **POTENTIAL INFRINGEMENT DETECTED**")
                                        else:
                                            st.markdown(f"**Rank {i+1}** - Final Score: **{result['final_similarity']:.2f}%** - "
                                                      f"✅ No infringement detected")
                                        
                                        st.markdown(f"File: {result['logo_name']}")
                                        
                                        # Create metrics for similarity scores
                                        col_a, col_b, col_c, col_d = st.columns(4)
                                        with col_a:
                                            st.metric("Text Score", f"{result['text_similarity']:.1f}%")
                                        with col_b:
                                            st.metric("Image Score", f"{result['image_score']:.1f}%")
                                        with col_c:
                                            st.metric("Color (Strict)", f"{result['color_similarity']:.1f}%")
                                        with col_d:
                                            st.metric("ViT (GPU)", f"{result['vit_similarity']:.1f}%")
                                        
                                        if result['text1'] or result['text2']:
                                            st.text(f"Extracted text: {result['text2']}")
                                    
                                    st.markdown("---")
                            
                            # Create detailed comparison table
                            st.subheader("📊 Detailed Comparison")
                            
                            comparison_data = {
                                'Rank': list(range(1, len(similarity_results) + 1)),
                                'Logo': [r['logo_name'] for r in similarity_results],
                                'Final Score (%)': [f"{r['final_similarity']:.2f}" for r in similarity_results],
                                'Infringement': [
                                    "⚠️ POTENTIAL INFRINGEMENT" if r['infringement_detected'] else "✅ No Infringement" 
                                    for r in similarity_results
                                ],
                                'Text (%)': [f"{r['text_similarity']:.2f}" for r in similarity_results],
                                'Image Score (%)': [f"{r['image_score']:.2f}" for r in similarity_results],
                                'Strict Color (%)': [f"{r['color_similarity']:.2f}" for r in similarity_results],
                                'GPU ViT (%)': [f"{r['vit_similarity']:.2f}" for r in similarity_results]
                            }
                            
                            comparison_df = pd.DataFrame(comparison_data)
                            st.dataframe(comparison_df, use_container_width=True)
                            
                            # Performance metrics
                            st.subheader("🚀 Performance Metrics")
                            col1, col2, col3, col4 = st.columns(4)
                            with col1:
                                st.metric("Processing Time", f"{processing_time:.2f}s")
                            with col2:
                                st.metric("Images/Second", f"{images_per_second:.1f}")
                            with col3:
                                if torch.cuda.is_available():
                                    memory_used = torch.cuda.memory_allocated() / 1e9
                                    st.metric("GPU Memory Used", f"{memory_used:.2f} GB")
                                else:
                                    st.metric("GPU Memory Used", "N/A")
                            with col4:
                                st.metric("Batch Size Used", batch_size)
                            
                            # Clean up
                            os.unlink(reference_logo_path)
                            if torch.cuda.is_available():
                                torch.cuda.empty_cache()
                    
                    except Exception as e:
                        st.error(f"Strict analysis failed: {str(e)}")
                        st.exception(e)
    
    # Footer
    st.markdown("---")
    st.markdown("🎯 Strict Color Similarity Logo Ranking System © 2025")

if __name__ == "__main__":
    main()
